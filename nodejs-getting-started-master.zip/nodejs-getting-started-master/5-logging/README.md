# 5 - Logging app events

![Datastore Build Status][ci-badge-datastore]

[ci-badge-datastore]: https://storage.googleapis.com/nodejs-getting-started-tests-badges/5-datastore.svg

This folder contains the sample code for the [Logging app events][step-5]
tutorial. Please refer to the tutorial for instructions on configuring, running,
and deploying this sample.

[step-5]: https://cloud.google.com/nodejs/getting-started/logging-application-events