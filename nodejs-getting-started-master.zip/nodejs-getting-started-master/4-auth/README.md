# 4 - Authenticating users

![Datastore Build Status][ci-badge-datastore]

[ci-badge-datastore]: https://storage.googleapis.com/nodejs-getting-started-tests-badges/4-datastore.svg

This folder contains the sample code for the [Authenticating users][step-4]
tutorial. Please refer to the tutorial for instructions on configuring, running,
and deploying this sample.

[step-4]: https://cloud.google.com/nodejs/getting-started/authenticate-users