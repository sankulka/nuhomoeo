# 6 - Using Cloud Pub/Sub

![Datastore Build Status][ci-badge-datastore]

[ci-badge-datastore]: https://storage.googleapis.com/nodejs-getting-started-tests-badges/6-datastore.svg

This folder contains the sample code for the [Using Cloud Pub/Sub][step-6]
tutorial. Please refer to the tutorial for instructions on configuring, running,
and deploying this sample.

[step-6]: https://cloud.google.com/nodejs/getting-started/using-pub-sub